from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.db import Base, engine
from app import models
from app.routers.admin import router as admin_router
from app.routers.admin_crud import router as crud_router
from app.routers.calorie_log import router as calorie_router
from app.routers.health import router as health_router
from app.routers.ingredients import router as ingredient_router
from app.routers.nutrition import router as nutrition_router
from app.routers.nutrition_profile import router as profile_router
from app.routers.recipes import router as recipe_router
from app.routers.recommendations import router as recommendation_router
from app.routers.search import router as search_router

app=FastAPI(title=settings.app_name,version='1.5.0')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
@app.on_event('startup')
def startup(): Base.metadata.create_all(bind=engine)
@app.get('/api/health')
def health(): return {'success':True,'data':{'status':'healthy','version':'1.5.0'}}
for r in [admin_router,crud_router,calorie_router,health_router,ingredient_router,nutrition_router,profile_router,recipe_router,recommendation_router,search_router]: app.include_router(r,prefix='/api')
